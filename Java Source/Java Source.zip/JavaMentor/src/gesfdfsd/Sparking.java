package gesfdfsd;

public interface Sparking {
	public void getSarkingWater();
}
