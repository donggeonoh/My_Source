package com.study.report6;

public class Main {

	public static void main(String[] args) {
		NumberBaseballGame numberBaseballGame = new NumberBaseballGame();
		
		numberBaseballGame.startGame();
	}
}