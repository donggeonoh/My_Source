package test;

public class Main {
  
      public static void main(String[] args) {
 
             GameSystem gameSystem =  new GameSystem();
             
      
      }
	
	
}
