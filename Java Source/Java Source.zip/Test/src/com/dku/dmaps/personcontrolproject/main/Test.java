package com.dku.dmaps.personcontrolproject.main;

public class Test {
	
	int x, y, z;
	
	public Test(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public Test(int x) {
		this.x = x;
		this.x = 10;
	}
	
}