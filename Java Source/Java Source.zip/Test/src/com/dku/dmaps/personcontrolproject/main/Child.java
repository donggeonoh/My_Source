package com.dku.dmaps.personcontrolproject.main;

public class Child extends Test {

	public Child(int x) {
		super(x);
	}

}
