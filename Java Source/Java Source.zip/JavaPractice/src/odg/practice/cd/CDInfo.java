package odg.practice.cd;

public class CDInfo {

}
