package com.study.report4;

public class MonsterGoblin extends Monster{

	public MonsterGoblin(String name, int hp, int ap, int dp) {
		this.name = name;
		this.hp = hp;
		this.ap = ap;
		this.dp = dp;
	}
}
