package com.study.duckproject;

public interface QuackBehavior {
	public void quack();
}