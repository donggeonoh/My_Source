package com.study.monster;

public class Monster extends Unit{
	
	public Monster(int hp, int ap, int dp) {
		this.hp = hp;
		this.ap = ap;
		this.dp = dp;
	}
}
