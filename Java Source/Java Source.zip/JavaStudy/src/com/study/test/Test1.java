package com.study.test;
/*
import java.util.Random;

public class Test1 {
	   Random random=new Random();
	   int health;
	   
	   public Test1() {
	      health=(random.nextInt(5)+1)*100;;
	   }
	   
	   void attack(Test1 M) {
	      if(M.health >= 10)   M.health-=10;
	      else M.health = 0;
	   }
	   
	   void healthCheck() {
		      System.out.println("Monster�� health�� " + health + "�Դϴ�");
		}
	   
	   int deadMonster() {
		   if(health == 0) return 1;
		   
		   return 0;
	   }
}
*/

