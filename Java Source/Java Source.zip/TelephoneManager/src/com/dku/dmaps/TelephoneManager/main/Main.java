package com.dku.dmaps.TelephoneManager.main;

import com.dku.dmaps.TelephoneManager.VO.Humint;
import com.dku.dmaps.TelephoneManager.control.Controller;
import com.dku.dmaps.TelephoneManager.model.Manager;
import com.dku.dmaps.TelephoneManager.view.MenuBoard;
import com.dku.dmaps.TelephoneManager.view.UtilityBoard;

public class Main {

	public static void main(String[] args) {
		new MenuBoard();
		
	}

}