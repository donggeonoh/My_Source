package com.telephoneManager.main;

import com.telephoneManager.view.MainBoard;

public class Main {

	public static void main(String[] args) {
		
		new MainBoard();
	
	}
}