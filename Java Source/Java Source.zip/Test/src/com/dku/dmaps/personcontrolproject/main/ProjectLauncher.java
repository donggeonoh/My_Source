package com.dku.dmaps.personcontrolproject.main;

import com.dku.dmaps.personcontrolproject.model.Manager;
import com.dku.dmaps.personcontrolproject.view.MainBoard;
import com.dku.dmaps.personcontrolproject.vo.Person;

public class ProjectLauncher {
	public static void main(String [] arsg) {

		new MainBoard();
	}
}
