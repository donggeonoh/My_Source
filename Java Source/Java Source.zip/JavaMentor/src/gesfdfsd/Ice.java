package gesfdfsd;

public interface Ice {
	public void getIce();
}
