package com.dku.dmap.study.test;

public interface ActionInterface {
	public void changeColor();
}
