package ssssss;

public interface Repariable {

	void repair();

	void repair(Readable r);
	
}
