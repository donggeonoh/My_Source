package com.study.report4;

public class Monster extends Unit {
	
}