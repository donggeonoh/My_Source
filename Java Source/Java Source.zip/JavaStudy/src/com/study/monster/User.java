package com.study.monster;

public class User extends Unit{
	
	public User(int hp, int ap, int dp) {
		this.hp = hp;
		this.ap = ap;
		this.dp = dp;
	}
}
