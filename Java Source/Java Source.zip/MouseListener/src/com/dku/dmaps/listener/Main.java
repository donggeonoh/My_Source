package com.dku.dmaps.listener;

public class Main {
	public static void main(String[] args) {
		new DragLine();
	}
}