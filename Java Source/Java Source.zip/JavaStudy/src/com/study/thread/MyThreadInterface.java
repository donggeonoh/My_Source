package com.study.thread;

public class MyThreadInterface {
	
}