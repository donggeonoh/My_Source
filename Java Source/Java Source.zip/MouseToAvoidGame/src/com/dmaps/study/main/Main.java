package com.dmaps.study.main;

import javax.swing.JFrame;

import com.dmaps.study.view.PhotoFrame;

public class Main {

	public static void main(String[] args) {
			
			new PhotoFrame();
	}
}