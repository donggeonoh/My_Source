package com.study.duckproject;

public class MuteQuack 
	implements QuackBehavior {

	@Override
	public void quack() {
		System.out.println("...");
		
	}

}