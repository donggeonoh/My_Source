package com.dku.dmap.study.homework;

public class m2 {
	int hp = 100;
	

	int getHp() {
		return hp;
	}
}
