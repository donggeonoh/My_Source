package com.dku.dmaps.main;

import com.dku.dmaps.view.MainBoard;

public class ProjectLauncher {
	public static void main(String [] arsg) {
	
		MainBoard mainBoard = new MainBoard();
		
	}
}
