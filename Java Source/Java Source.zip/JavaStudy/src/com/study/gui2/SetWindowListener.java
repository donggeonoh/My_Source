package com.study.gui2;

import java.awt.event.WindowEvent;

public interface SetWindowListener{
	void windowClosing(WindowEvent e);
}