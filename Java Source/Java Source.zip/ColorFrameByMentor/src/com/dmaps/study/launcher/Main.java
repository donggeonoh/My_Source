package com.dmaps.study.launcher;

public class Main {
	public static void main(String [] args) {
		new ColorChangeProgram();
	}
	
}
