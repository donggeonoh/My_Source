package com.study.gui;

import java.awt.Button;

public class CustomButton extends Button{
	
	public CustomButton(String name) {
		super(name);
	}
	
}