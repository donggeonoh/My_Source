package odg.practice.floor;

public class Floor {
	
	static int MAXJUMP;
	int numberOfStair;
	
	public Floor(int numberOfStair, int MAXJUMP) {
		this.numberOfStair = numberOfStair;
		this.MAXJUMP = MAXJUMP;
	}
	
	public void findTheNumberOfCases() {
		
	}
	
}