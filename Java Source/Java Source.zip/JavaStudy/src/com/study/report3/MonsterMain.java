package com.study.report3;

public class MonsterMain {

	public static void main(String[] args) {
		FightMonster f = new FightMonster();
	}
}