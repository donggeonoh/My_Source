package com.study.duckproject;

public interface FlyBehavior {
	public void fly();
}
