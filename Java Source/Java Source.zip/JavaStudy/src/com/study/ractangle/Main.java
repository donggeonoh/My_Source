package com.study.ractangle;

public class Main {

	public static void main(String[] args) {
		Ractangle ractangle = new Ractangle(9, 5, 3, 1);
		
		ractangle.distance();
		ractangle.extent();
	}

}
