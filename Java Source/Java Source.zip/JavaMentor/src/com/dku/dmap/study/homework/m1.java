package com.dku.dmap.study.homework;

public class m1 {

	public void attacker(m2 m2) {
		System.out.println("���ȴ�.");
		m2.hp -= 10;
	}
	
}
