package com.dku.dmaps.personcontrolproject.main;

public class GrandChild extends Child{

	public GrandChild(int x) {
		super(x);
	}
	
}
