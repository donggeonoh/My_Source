package com.telephoneManager.view;

import java.util.ArrayList;

import javax.swing.JFrame;

import com.telephoneManager.VO.Data;

public class Board extends JFrame{
	public void printDataList(ArrayList<Data> dataList) {
		
	}
}
