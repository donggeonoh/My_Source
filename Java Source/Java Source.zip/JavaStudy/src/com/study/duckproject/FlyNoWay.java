package com.study.duckproject;

public class FlyNoWay 
	implements FlyBehavior{
	
	@Override
	public void fly() {
		System.out.println("���� ���ؿ�.");
	}
}
